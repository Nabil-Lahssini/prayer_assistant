"""Individual prayer object"""
class Prayer:
    def __init__(self, name, time):
        self.name = name
        self.time = time
