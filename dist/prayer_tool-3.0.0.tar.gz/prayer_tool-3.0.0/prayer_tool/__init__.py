# __init__.py

# Version of the prayer_tool package
__version__ = "3.0.0"